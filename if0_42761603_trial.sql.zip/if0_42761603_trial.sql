-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql302.infinityfree.com
-- Generation Time: Sep 09, 2026 at 01:20 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_42761603_trial`
--

-- --------------------------------------------------------

--
-- Table structure for table `balance_logs`
--

CREATE TABLE `balance_logs` (
  `id` int(11) NOT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `account_name` varchar(100) NOT NULL,
  `topup_added` decimal(10,2) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `logged_by` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `balance_logs`
--

INSERT INTO `balance_logs` (`id`, `shift_id`, `account_name`, `topup_added`, `note`, `logged_by`, `date_time`) VALUES
(1, 1, 'dinaga', '200.00', NULL, 'lance', '2026-09-08 21:42:24'),
(2, 2, 'lance', '200.00', 'free time', 'lance', '2026-09-08 21:53:06'),
(3, 2, 'dinaga', '0.50', 'autodeduction need topup for promo', 'lance', '2026-09-08 21:53:34');

-- --------------------------------------------------------

--
-- Table structure for table `cash_counter_logs`
--

CREATE TABLE `cash_counter_logs` (
  `id` int(11) NOT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `c1000` int(11) DEFAULT 0,
  `c500` int(11) DEFAULT 0,
  `c200` int(11) DEFAULT 0,
  `c100` int(11) DEFAULT 0,
  `c50` int(11) DEFAULT 0,
  `c20` int(11) DEFAULT 0,
  `c10` int(11) DEFAULT 0,
  `c5` int(11) DEFAULT 0,
  `c1` int(11) DEFAULT 0,
  `gcash` decimal(10,2) DEFAULT 0.00,
  `grand_total` decimal(10,2) DEFAULT 0.00,
  `logged_by` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cash_counter_logs`
--

INSERT INTO `cash_counter_logs` (`id`, `shift_id`, `c1000`, `c500`, `c200`, `c100`, `c50`, `c20`, `c10`, `c5`, `c1`, `gcash`, `grand_total`, `logged_by`, `date_time`) VALUES
(1, 1, 12, 13, 18, 13, 13, 11, 16, 13, 13, '0.00', '24508.00', 'lance', '2026-09-08 21:28:28'),
(2, 2, 25, 0, 1, 0, 1, 0, 0, 1, 3, '1000.00', '26258.00', 'lance', '2026-09-08 21:52:03');

-- --------------------------------------------------------

--
-- Table structure for table `expense_logs`
--

CREATE TABLE `expense_logs` (
  `id` int(11) NOT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `item_name` varchar(150) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','gcash') DEFAULT 'cash',
  `logged_by` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `expense_logs`
--

INSERT INTO `expense_logs` (`id`, `shift_id`, `item_name`, `amount`, `payment_method`, `logged_by`, `date_time`) VALUES
(1, 1, 'pizza', '150.00', 'cash', 'lance', '2026-09-08 21:42:41'),
(2, 2, 'sahod', '400.00', 'cash', 'lance', '2026-09-08 21:53:52'),
(3, 2, 'trashbag', '150.00', 'cash', 'lance', '2026-09-08 21:54:00');

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE `records` (
  `id` int(11) NOT NULL,
  `date_time` datetime DEFAULT current_timestamp(),
  `category` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `actual_balance` decimal(10,2) DEFAULT 0.00,
  `topup_added` decimal(10,2) DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shifts`
--

CREATE TABLE `shifts` (
  `id` int(11) NOT NULL,
  `shift_period_id` int(11) NOT NULL,
  `shift_type` enum('morning','night') NOT NULL,
  `starting_cash` decimal(10,2) DEFAULT 0.00,
  `starting_gcash` decimal(10,2) DEFAULT 0.00,
  `ending_cash` decimal(10,2) DEFAULT 0.00,
  `ending_gcash` decimal(10,2) DEFAULT 0.00,
  `status` enum('open','closed') DEFAULT 'open',
  `opened_by` varchar(50) NOT NULL,
  `closed_by` varchar(50) DEFAULT NULL,
  `opened_at` datetime NOT NULL,
  `closed_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `shifts`
--

INSERT INTO `shifts` (`id`, `shift_period_id`, `shift_type`, `starting_cash`, `starting_gcash`, `ending_cash`, `ending_gcash`, `status`, `opened_by`, `closed_by`, `opened_at`, `closed_at`, `notes`) VALUES
(1, 1, 'morning', '24508.00', '0.00', '25258.00', '1000.00', 'closed', 'lance', 'lance', '2026-09-08 21:28:12', '2026-09-08 21:42:49', ''),
(2, 1, 'night', '25258.00', '1000.00', '26708.00', '1200.00', 'closed', 'lance', 'lance', '2026-09-08 21:50:37', '2026-09-08 21:54:08', '');

-- --------------------------------------------------------

--
-- Table structure for table `shift_log_entries`
--

CREATE TABLE `shift_log_entries` (
  `id` int(11) NOT NULL,
  `shift_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','gcash') DEFAULT 'cash',
  `note` varchar(255) DEFAULT NULL,
  `logged_by` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `shift_log_entries`
--

INSERT INTO `shift_log_entries` (`id`, `shift_id`, `amount`, `payment_method`, `note`, `logged_by`, `date_time`) VALUES
(1, 1, '200.00', 'cash', '', 'lance', '2026-09-08 21:41:42'),
(2, 1, '300.00', 'cash', '', 'lance', '2026-09-08 21:41:47'),
(3, 1, '400.00', 'cash', '', 'lance', '2026-09-08 21:41:52'),
(4, 1, '1000.00', 'gcash', '', 'lance', '2026-09-08 21:41:58'),
(5, 2, '500.00', 'cash', '', 'lance', '2026-09-08 21:52:30'),
(6, 2, '200.00', 'cash', '', 'lance', '2026-09-08 21:52:35'),
(7, 2, '300.00', 'cash', '', 'lance', '2026-09-08 21:52:39'),
(8, 2, '1000.00', 'cash', '', 'lance', '2026-09-08 21:52:44'),
(9, 2, '200.00', 'gcash', '', 'lance', '2026-09-08 21:52:49');

-- --------------------------------------------------------

--
-- Table structure for table `shift_periods`
--

CREATE TABLE `shift_periods` (
  `id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `label` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `shift_periods`
--

INSERT INTO `shift_periods` (`id`, `start_date`, `end_date`, `label`, `created_at`) VALUES
(1, '2026-09-09', '2026-09-10', 'Sep 9–Sep 10', '2026-09-08 21:28:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') DEFAULT 'staff',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$10$GyH7Q1CfLnogmvikaW7eR.3aY0otN1AxhZAlnEHkfcGEM360ngWbu', 'admin', '2026-09-08 21:27:10'),
(2, 'dominic', '$2y$10$yXnTj4EsIx/GlVtujjqk5ujLz7AvlykntDnZTMnOzdFTJnXcFFOZW', 'admin', '2026-09-08 21:27:10'),
(3, 'lance', '$2y$10$DStsiVWj8iA0D7g/WgGb8e5F/8luapIosxoBcr53.g363mrjaWdhS', 'staff', '2026-09-08 21:27:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `balance_logs`
--
ALTER TABLE `balance_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shift_id` (`shift_id`);

--
-- Indexes for table `cash_counter_logs`
--
ALTER TABLE `cash_counter_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shift_id` (`shift_id`);

--
-- Indexes for table `expense_logs`
--
ALTER TABLE `expense_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shift_id` (`shift_id`);

--
-- Indexes for table `records`
--
ALTER TABLE `records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shifts`
--
ALTER TABLE `shifts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shift_period_id` (`shift_period_id`);

--
-- Indexes for table `shift_log_entries`
--
ALTER TABLE `shift_log_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shift_id` (`shift_id`);

--
-- Indexes for table `shift_periods`
--
ALTER TABLE `shift_periods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `balance_logs`
--
ALTER TABLE `balance_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cash_counter_logs`
--
ALTER TABLE `cash_counter_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `expense_logs`
--
ALTER TABLE `expense_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `records`
--
ALTER TABLE `records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shifts`
--
ALTER TABLE `shifts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `shift_log_entries`
--
ALTER TABLE `shift_log_entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `shift_periods`
--
ALTER TABLE `shift_periods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
